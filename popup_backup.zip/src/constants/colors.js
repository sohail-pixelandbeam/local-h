export const acolors = {
    primary: "#35208e",
    white: "#ffffff",
    btnPrimary: "#ffa183",
    btnSecondry: "#ffa183",
    grey: "#5d5760",
    lighGrey: "#DADADA",
    primaryLight: '#5B4DBC',
    storyTitleContainerBg: 'rgba(91, 77, 188,0.7)',
    mapPointerBg: 'rgba(91, 77, 188,0.5)'
}