export const fonts = {

    PRe: 'Poppins-Regular',
    PMe: 'Poppins-Medium',
    PSBo: 'Poppins-SemiBold',
    PBo: 'Poppins-Bold',
    PSBIt: 'Poppins-SemiBoldItalic',
    PEBo : 'Poppins-ExtraBold',

    MRe: 'Poppins-Regular',
    MMe: 'Poppins-Medium',
    MSBo: 'Poppins-SemiBold',
    MBo: 'Poppins-Bold',
    MLi: 'Montserrat-Light'
    // MRe: 'Montserrat-Regular',
    // MMe: 'Montserrat-Medium',
    // MSBo: 'Montserrat-SemiBold',
    // MBo: 'Montserrat-Bold',
    // MLi: 'Montserrat-Light'
}