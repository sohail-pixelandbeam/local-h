export const acolors = {
    primary: "#35208e",
    white: "#ffffff",
    btnPrimary: "#ffa183",
    btnSecondry: "#ffa183",
    grey : "#5d5760",
    lighGrey: "#DADADA"
}