import React from 'react'
import { Text, View, } from 'react-native'

const Favourites = () => {
    return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: 'black' }}>Favourites.js</Text>
        </View>
    )
}

export default Favourites
