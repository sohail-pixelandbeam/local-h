export const urls = {
  
  // API: "http://3.125.50.99:3001/",
  // API: "http://52.57.23.48:3001/api/v1/",
  API: "http://13.48.31.205:3001/api/v1/",
  

  // PHP_API: "http://3.125.50.99:3001/",
  // Image_Uri: "http://3.125.50.99:3001/",

  //... more colors here
  MARGIN: false,
  error_title: "No Internet",
  error: "Error connecting to the server, please try again later",
  D_LIMIT: 120

  // mersruveysapp@gmail.com
  // P145DeDevelopers
};